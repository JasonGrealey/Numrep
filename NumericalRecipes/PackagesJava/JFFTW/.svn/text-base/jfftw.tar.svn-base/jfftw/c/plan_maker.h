/*
 *                ANSI header file for plan_maker
 */
fftw_plan complex_interleaved_plan(int, int, int, double *,double *,
				   int,unsigned int);

fftw_plan complex_split_plan(int, int, int, double *, double *,
			     double *, double *,unsigned int);

fftw_plan r2c_plan(int, int, int,double *,double *, unsigned int);

fftw_plan c2r_plan(int, int, int, double *, double *, unsigned int);



