/*       C implementation of the FFTWReal natives.
 *       Author Will Hossacl, 2008
 */
#include "jnimacros.h"
#include "jfftw_FFTWReal.h"
#include <fftw3.h>
#include <stdio.h>
#include "plan_maker.h"

/*
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 */




/**          nativeForward function.
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeForward
  (JNIEnv *env, jobject obj, jint width, jint height, 
   jint depth, jdoubleArray in, jdoubleArray out, jint flag) {
  
   double *inptr, *outptr;           // input and output array pointers
   fftw_plan plan;                   // The plan

   inptr = GetDoubleArray(in);                // Get input array
   outptr = GetDoubleArray(out);              // Get output array

   //         Make the plan (using plan_maker method)
   plan = r2c_plan(width,height,depth,inptr,outptr,(unsigned int)flag);

   fftw_execute(plan);                       // Do the FFT
   fftw_destroy_plan(plan);                  // Clear up
 
   ReleaseDoubleArray(in,inptr);             // Release the arrays
   ReleaseDoubleArray(out,outptr);
}

/**          nativeBackwards function.
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeBackward
 (JNIEnv *env, jobject obj, jint width, jint height, 
   jint depth, jdoubleArray in, jdoubleArray out, jint flag) {
   double *inptr, *outptr;           // input and output array pointers
   fftw_plan plan;                   // The plan

   inptr = GetDoubleArray(in);                // Get input array
   outptr = GetDoubleArray(out);              // Get output array

   //         Make the plan (using plan_maker method)
   plan = c2r_plan(width,height,depth,inptr,outptr,(unsigned int)flag);

   fftw_execute(plan);                       // Do the FFT
   fftw_destroy_plan(plan);                  // Clear up
 
   ReleaseDoubleArray(in,inptr);             // Release the arrays
   ReleaseDoubleArray(out,outptr);
}
  


/*               nativeOneDimensionalForward
 */

JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeOneDimensionalForward
(JNIEnv *env, jobject obj, jdoubleArray in, jdoubleArray out, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers  
  int length;                                 // Transform length
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array
  length = ArrayLength(in);                  // Length of transform

  plan = fftw_plan_dft_r2c_1d(length,inptr,(fftw_complex*)outptr,
			      (unsigned int)flag);

  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
 
  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}


/*               nativeOneDimensionalBackward
 */

JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeOneDimensionalBackward
(JNIEnv *env, jobject obj, jdoubleArray in, jdoubleArray out, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers  
  int length;                                 // Transform length
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array
  length = ArrayLength(out);                  // Length of transform (output)

  plan = fftw_plan_dft_c2r_1d(length,(fftw_complex*)inptr,outptr,
			      (unsigned int)flag);

  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}

/*                            twoDimensionaForward
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeTwoDimensionalForward
(JNIEnv *env , jobject obj, jint width, jint height, jdoubleArray in, jdoubleArray out, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers  
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  
  //                    Make the two-d plan
  plan = fftw_plan_dft_r2c_2d(height,width,inptr,
			      (fftw_complex*)outptr,
			      (unsigned int)flag);
  
  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}


/*                            twoDimensionaBackward
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeTwoDimensionalBackward
(JNIEnv *env , jobject obj, jint width, jint height, jdoubleArray in, jdoubleArray out, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers  
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  
  //                    Make the two-d plan
  plan = fftw_plan_dft_c2r_2d(height,width,(fftw_complex*)inptr,
			      outptr,(unsigned int)flag);
  
  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}


/*                         threeDimensionalForward
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeThreeDimensionalForward
(JNIEnv *env, jobject obj, jint width, jint height, jint depth, 
 jdoubleArray in, jdoubleArray out, jint flag) {

  double *inptr, *outptr;                    // input and output array pointers
  fftw_plan plan;                            // the plan

  
  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  
  //                    Make the three-d plan
  plan = fftw_plan_dft_r2c_3d(depth,height,width,inptr,
			      (fftw_complex*)outptr,
			      (unsigned int)flag);
  
  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}

/*                            threeDimensionaBackward
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWReal_nativeThreeDimensionalBackward
(JNIEnv *env , jobject obj, jint width, jint height, jint depth, jdoubleArray in, jdoubleArray out, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers  
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  
  //                    Make the two-d plan
  plan = fftw_plan_dft_c2r_3d(depth,height,width,(fftw_complex*)inptr,
			      outptr,(unsigned int)flag);
  
  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}




