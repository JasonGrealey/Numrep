#include <fftw3.h>
#include <stdlib.h>
#include "plan_maker.h"


/**               C fft engine interface
 */

static fftw_plan *plans = NULL;
static int maxplan = 0;
static int nextplan = 0;


/**               function to add a plan to the engine
 */
int engine_addplan(int i, fftw_plan plan) {
  
  //                plan id is zero, add to the ``end''
  if (i == 0 ) {
    i = nextplan;
    nextplan++;
  }
  //                extend the static plan array if needed
  if (i >= maxplan) {
    maxplan += 16;
    plans = (fftw_plan*)realloc(plans,maxplan*sizeof(fftw_plan*));
  }

  plans[i] = plan;           // Set the plan

  return i;                  // return plan id
}

/**               function to execute the specifed plan 
*/
int engine_executeplan(int i) {
  fftw_execute(plans[i]);
  return 1;
}

/**              functio to delte a speficic plan
 */
int engine_deleteplan(int i) {
  fftw_destroy_plan(plans[i]);
}
