/*          C implementation for FFT.java natives
 */
#include "jnimacros.h"
#include "jfftw_FFTW.h"
#include <fftw3.h>
#include <stdio.h>


/*
 *     Author Will Hossack, 2008
 *
 *     This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

/*          nativeLoadWisdomFromFile method
 */
JNIEXPORT jboolean JNICALL Java_jfftw_FFTW_nativeLoadWisdomFromFile
(JNIEnv *env, jobject obj, jstring jfilename) {

  const char *filename;           // Filename in c format
  FILE *file;                     // The input file
  jboolean status = 0;            // status flag
  
  filename = GetString(jfilename);        // Get string in C format

  // printf("Wisdom file is %s\n",filename);
  
  file = fopen(filename,"r");             // Try and open file
  if (file != NULL) {                     // Try to read wisdom
    status = (jboolean)fftw_import_wisdom_from_file(file);
    fclose(file);
  }

  ReleaseString(jfilename,filename);      // release file
  return status;                          // Return status
  }

/*          nativeLoadWisdomFromString
 */
JNIEXPORT jboolean JNICALL Java_jfftw_FFTW_nativeLoadWisdomFromString
(JNIEnv *env, jobject obj, jstring jwisdom) {
  
  const char *wisdom = GetString(jwisdom);              // Get string in C format
  jboolean status  = (jboolean)fftw_import_wisdom_from_string(wisdom);
  ReleaseString(jwisdom,wisdom);
  return status;
}




/*          nativeClearWisdom method
 */
JNIEXPORT void JNICALL Java_jfftw_FFTW_nativeClearWisdom
(JNIEnv *env, jobject obj){
  fftw_forget_wisdom();                 // Simple void call
}


/*          nativeExportWisdomToFile method
 */

JNIEXPORT jboolean JNICALL Java_jfftw_FFTW_nativeExportWisdomToFile
(JNIEnv *env, jobject obj, jstring jfilename) {
  
  const char *filename;           // Filename in c format
  FILE *file;                     // The input file
  jboolean status = 0;            // status flag
  
  filename = GetString(jfilename);        // Get string in C format

  // printf("Wisdom output file is %s\n",filename);
  
  file = fopen(filename,"w");            // Try and open file
  if (file != NULL) {
    fftw_export_wisdom_to_file(file);    // Do the write
    fclose(file);
    status = 1;                          // Set statue
  }

  
  ReleaseString(jfilename,filename);      // release file
  return status;                          // Return status
  }


/*             nativeGetWisdom
 */

JNIEXPORT jstring JNICALL Java_jfftw_FFTW_nativeGetWisdom
(JNIEnv *env, jobject obj){
  
  char *wisdom = fftw_export_wisdom_to_string();   // Get the wisdom

  jstring jwisdom = NewString(wisdom);             // Make new java string
  fftw_free(wisdom );                              // Deallocate wisdom

  return jwisdom;                                  // return j staring
}



  
