#include <fftw3.h>
#include <stdlib.h>
#include "plan_maker.h"

/*
 *     Series of c calls to simply the making of fftw plans
 */


/**    Function to make a complex interleaved plan. The diminsion
 *     of the transform will depend on the supplied parameters. 
 *     Parameters   w the width
 *                  h the height
 *                  d the depth
 *                  in  the input double interleaved array
 *                  out the output double interleaved array
 *                  dirn +/- 1
 *                  flag plan flag
 *    If h == 1 && d == 1  ->      one-dimensions
 *       d == 1            ->      two-dimensions
 *                else     ->      three-dimensions
 */
fftw_plan complex_interleaved_plan(int w, int h, int d, 
				  double *in,
				  double *out,
				  int dirn,
				  unsigned int flag) {

  //        Work out if its 1, 2 or 3 dimensions
  if (h == 1 && d == 1) {           // One dimensional
    return fftw_plan_dft_1d(w,
			    (fftw_complex*)in,
			    (fftw_complex*)out,dirn,flag);
  }
  else if (d == 1) {                // Two dimensional
    return fftw_plan_dft_2d(h,w,(fftw_complex*)in,
			    (fftw_complex*)out,dirn,flag);
  }
  else  {                            // Full three dimensional
    return fftw_plan_dft_3d(d,h,w,(fftw_complex*)in,
			    (fftw_complex*)out,dirn,flag);
  }
}   


/**   function to make complex interleaved fftw_plan. The dimension
 *    of the transform will depend on the supplied parameters.
 *    Parameters    w the width
 *                  h the height
 *                  d the depth
 *                  realin  real part if input array
 *                  imagin  imaginary part of input array
 *                  realout real part of output array
 *                  imagout imarinary part of output array
 *                  dirn +/- 1
 *                  flag plan flag
 *    If h == 1 && d == 1  ->      one-dimensions
 *       d == 1            ->      two-dimensions
 *                else     ->      three-dimensions
 */   
fftw_plan complex_split_plan(int w, int h, int d,
			     double *realin, double *imagin,
			     double *realout, double *imagout,
			     unsigned int flag) {
 
  fftw_iodim *dim = (fftw_iodim*)(malloc(sizeof(fftw_iodim)*3));
  
  dim[0].n = w;                             // First dimension
  dim[0].is = 1;                            // First dimension in span
  dim[0].os = 1;                            // First dimension out span  
  dim[1].n = h;                             // Second dimension
  dim[1].is = w;                            // Secpnd dimension in span
  dim[1].os = w;                            // Second dimension out span
  dim[2].n = d;                             // Third dimension
  dim[2].is = w*h;                          // Third dimension in span
  dim[2].os = w*h;                          // Third dimension out span

  //                  Work out the order
  if (d == 1 && h == 1) {                   // One dimensional
    return fftw_plan_guru_split_dft(1,dim,0,dim,
                                  realin,imagin,
                                  realout,imagout,
                                  (unsigned int)flag);
  }
  else if (d == 1) {
    return fftw_plan_guru_split_dft(2,dim,0,dim,
                                  realin,imagin,
                                  realout,imagout,
                                  (unsigned int)flag);
  }
  else {
     return fftw_plan_guru_split_dft(3,dim,0,dim,
                                  realin,imagin,
                                  realout,imagout,
                                  (unsigned int)flag);
  }
}



/**    Function to make real to complex plans with the dimension
 *     set by the specifying parameters.
 *
 *     Parameters   w the width
 *                  h the height
 *                  d the depth
 *                  in  the input double array
 *                  out the output double interleaved array
 *                  flag plan flag
 *    If h == 1 && d == 1  ->      one-dimensions
 *       d == 1            ->      two-dimensions
 *                else     ->      three-dimensions
 */ 
fftw_plan r2c_plan(int w, int h, int d,
		   double *in,
		   double *out,
		   unsigned int flag) {

  if (h == 1 && d == 1) {                 // One dimensional
    return fftw_plan_dft_r2c_1d(w,in,
				(fftw_complex*)out,flag);
  }
  else if (h == 1) {                      // Two dimensional
    return fftw_plan_dft_r2c_2d(h,w,in,
				(fftw_complex*)out,flag);
  }
  else {                                  // Three dimensional
    return fftw_plan_dft_r2c_3d(d,h,w,in,
				(fftw_complex*)out,flag);
  }
}


/**    Function to make real to complex plans with the dimension
 *     set by the specifying parameters.
 *
 *     Parameters   w the width
 *                  h the height
 *                  d the depth
 *                  in  the input double interleaved array
 *                  out the output double  array
 *                  flag plan flag
 *    If h == 1 && d == 1  ->      one-dimensions
 *       d == 1            ->      two-dimensions
 *                else     ->      three-dimensions
 */ 
fftw_plan c2r_plan(int w, int h, int d, 
		   double *in,
		   double *out,
		   unsigned int flag) {

  
  if (h == 1 && d == 1) {                 // One dimensional
    return fftw_plan_dft_c2r_1d(w,(fftw_complex*)in,
				out,flag);
  }
  else if (h == 1) {                      // Two dimensional
    return fftw_plan_dft_c2r_2d(h,w,(fftw_complex*)in,
				out,flag);
  }
  else {                                  // Three dimensional
    return fftw_plan_dft_c2r_3d(d,h,w,(fftw_complex*)in,
				out,flag);
  }
}




  
  
  
  
    

  

