/*         C impementation of the FFTWComplex native methods
 */
#include "jnimacros.h"
#include "jfftw_FFTWComplex.h"
#include <fftw3.h>
#include <stdlib.h>
#include "plan_maker.h"

/*
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 */



/**         General native interleaved complex fft
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeInterleave
  (JNIEnv *env, jobject obj, jint width, jint height, jint depth, 
   jdoubleArray in, jdoubleArray out, jint dirn, jint flag){
  
  double *inptr, *outptr;                     // input and output array pointers
  fftw_plan  plan;                            // the plan
  
  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array
  
  //                      Make plan using planmaker function
  plan = complex_interleaved_plan(width, height, depth, 
				  inptr,outptr, dirn,
				  (unsigned int) flag);
  
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  
  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}
  
/*      General native split complex fft
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeSplit
  (JNIEnv *env, jobject obj, jint width , jint height, jint depth, 
   jdoubleArray realin, jdoubleArray imagin, 
   jdoubleArray realout, jdoubleArray imagout, jint flag) {

  double *realinptr, *imaginptr, *realoutptr, *imagoutptr;
  fftw_plan plan;
  
  realinptr = GetDoubleArray(realin);        // Get real input array
  imaginptr = GetDoubleArray(imagin);        // Get imag input array
  realoutptr = GetDoubleArray(realout);      // Get real out array
  imagoutptr = GetDoubleArray(imagout);      // Get imag out array;

  plan = complex_split_plan(width, height, depth,
			     realinptr, imaginptr,
			     realoutptr, imagoutptr,
			    (unsigned int) flag);
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  
  ReleaseDoubleArray(realin,realinptr);             // Release the arrays
  ReleaseDoubleArray(imagin,imaginptr);
  ReleaseDoubleArray(realout,realoutptr);
  ReleaseDoubleArray(imagout,imagoutptr);
}

			 



/*         General native split complex fft
 */



/*           nativeOneDimensional
 */

JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeOneDimensional
(JNIEnv *env, jobject obj, jdoubleArray in, jdoubleArray out, jint dirn, jint flag){

  
  double *inptr, *outptr;                     // input and output array pointers
  int length;                                 // Transform length
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array
  length = ArrayLength(in)/2;                // Half length needed

  //          Make a simple plan using flag (default to ESTIMATE)
  plan = fftw_plan_dft_1d(length, (fftw_complex*)inptr,
                          (fftw_complex*)outptr,dirn,
                          (unsigned int)flag);

  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  
  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}

/*         nativeOneDimensinalSplit
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeOneDimensionalSplit
  (JNIEnv *env, jobject obj, jdoubleArray realin, jdoubleArray imagin, 
   jdoubleArray realout, jdoubleArray imagout , jint flag){

  double *realinptr, *imaginptr, *realoutptr, *imagoutptr;
  fftw_plan plan;
  fftw_iodim dim;
  
  realinptr = GetDoubleArray(realin);        // Get real input array
  imaginptr = GetDoubleArray(imagin);        // Get imag input array
  realoutptr = GetDoubleArray(realout);      // Get real out array
  imagoutptr = GetDoubleArray(imagout);      // Get imag out array;
  dim.n = ArrayLength(realin);               // Array length (all the same)
  dim.is = 1;                                // array span is 1
  dim.os = 1;
  
  //      Make plan using guru interface for split array
  plan = fftw_plan_guru_split_dft(1,&dim,0,&dim,
				  realinptr,imaginptr,
				  realoutptr,imagoutptr,
				  (unsigned int)flag);
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  
  ReleaseDoubleArray(realin,realinptr);             // Release the arrays
  ReleaseDoubleArray(imagin,imaginptr);
  ReleaseDoubleArray(realout,realoutptr);
  ReleaseDoubleArray(imagout,imagoutptr);
}

/*        nativeTwoDimensional
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeTwoDimensional
(JNIEnv *env, jobject obj, jint width, jint height, jdoubleArray in, jdoubleArray out, jint dirn, jint flag){


  double *inptr, *outptr;                     // input and output array pointers
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  //          Make a simple plan using flag (normall ESTIMATE)
  plan = fftw_plan_dft_2d(height,width, (fftw_complex*)inptr,
                          (fftw_complex*)outptr,dirn,
                          (unsigned int)flag);

  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}

/*     nativeTwoDimensinalSplit
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeTwoDimensionalSplit
  (JNIEnv *env, jobject obj, jint width, jint height, jdoubleArray realin, jdoubleArray imagin, 
   jdoubleArray realout, jdoubleArray imagout, jint flag) {
  
  double *realinptr, *imaginptr, *realoutptr, *imagoutptr;
  fftw_plan plan;
  fftw_iodim *dim = (fftw_iodim*)(malloc(sizeof(fftw_iodim)*2));
  
  realinptr = GetDoubleArray(realin);        // Get real input array
  imaginptr = GetDoubleArray(imagin);        // Get imag input array
  realoutptr = GetDoubleArray(realout);      // Get real out array
  imagoutptr = GetDoubleArray(imagout);      // Get imag out array;

  dim[0].n = width;                         // First dimension
  dim[0].is = 1;                            // First dimension in span
  dim[0].os = 1;                            // First dimension out span  
  dim[1].n = height;                        // Second dimension
  dim[1].is = width;                        // Secpnd dikension in span
  dim[1].os = width;                        // Second dimension out span

  
  //      Make plan using guru interface for two dimensional split array
  plan = fftw_plan_guru_split_dft(2,dim,0,dim,
				  realinptr,imaginptr,
				  realoutptr,imagoutptr,
				  (unsigned int)flag);
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  free(dim);
  
  ReleaseDoubleArray(realin,realinptr);             // Release the arrays
  ReleaseDoubleArray(imagin,imaginptr);
  ReleaseDoubleArray(realout,realoutptr);
  ReleaseDoubleArray(imagout,imagoutptr);
}



/*     nativeThreeDimensional
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeThreeDimensional
  (JNIEnv *env, jobject obj, jint width, jint height, jint depth, 
   jdoubleArray in, jdoubleArray out, jint dirn, jint flag){


  double *inptr, *outptr;                     // input and output array pointers
  fftw_plan  plan;                            // the plan

  inptr = GetDoubleArray(in);                // Get input array
  outptr = GetDoubleArray(out);              // get output array

  
  //          Make a simple plan using flag (normall ESTIMATE)
  plan = fftw_plan_dft_3d(depth,height,width, (fftw_complex*)inptr,
                          (fftw_complex*)outptr,dirn,(unsigned int)flag);

  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up

  ReleaseDoubleArray(in,inptr);             // Release the arrays
  ReleaseDoubleArray(out,outptr);
}


/*      nativeThreeDimsneionalSplit
 */
JNIEXPORT void JNICALL Java_jfftw_FFTWComplex_nativeThreeDimensionalSplit
  (JNIEnv *env, jobject obj, jint width, jint height , jint depth, 
   jdoubleArray realin, jdoubleArray imagin, jdoubleArray realout, jdoubleArray imagout, jint flag){

  
  double *realinptr, *imaginptr, *realoutptr, *imagoutptr;
  fftw_plan plan;
  fftw_iodim *dim = (fftw_iodim*)(malloc(sizeof(fftw_iodim)*3));
  
  realinptr = GetDoubleArray(realin);        // Get real input array
  imaginptr = GetDoubleArray(imagin);        // Get imag input array
  realoutptr = GetDoubleArray(realout);      // Get real out array
  imagoutptr = GetDoubleArray(imagout);      // Get imag out array;

  dim[0].n = width;                         // First dimension
  dim[0].is = 1;                            // First dimension in span
  dim[0].os = 1;                            // First dimension out span  
  dim[1].n = height;                        // Second dimension
  dim[1].is = width;                        // Secpnd dimension in span
  dim[1].os = width;                        // Second dimension out span
  dim[2].n = depth;                         // Third dimension
  dim[2].is = width*height;                 // Third dimension in span
  dim[2].os = width*height;                 // Third dimension out span

  
  //      Make plan using guru interface for three dimensional split array
  plan = fftw_plan_guru_split_dft(3,dim,0,dim,
				  realinptr,imaginptr,
				  realoutptr,imagoutptr,
				  (unsigned int)flag);
  fftw_execute(plan);                       // Do the FFT
  fftw_destroy_plan(plan);                  // Clear up
  free(dim);
  
  ReleaseDoubleArray(realin,realinptr);             // Release the arrays
  ReleaseDoubleArray(imagin,imaginptr);
  ReleaseDoubleArray(realout,realoutptr);
  ReleaseDoubleArray(imagout,imagoutptr);
}
