package jfftw;

/**    Class to for a (forward), Real to hermition complex FFT engine
 *     with a real input buffer and hermition complex output buffer.
 *     Note since there are in gerenal of diffent size, then they
 *     callon be the same array.
 */

public class FFTWComplexToRealEngine extends FFTWEngine {



    protected FFTWReal fft = new FFTWReal(this);

    /**       Form a three-dimensional ComplexToReal Engine
     *        specified input and output buffers.
     *        @param w the width   (or real data)
     *        @param h the height
     *        @param d the depth
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexToRealEngine(int w, int h, int d,
				   double[] in,
				   double[] out) {
	//       Basic sanity checks!!
	if (in == null || out == null || in == out ) {
            throw new NullPointerException(
 "FFTWRealToComplexEngine: called with null data array or same in/out arrays");
        }

	int iw = (w/2 + 1);               // Output width
	if (in.length != 2*iw*d*h) {
	    throw new IllegalArgumentException(
            "FFTWRealToComplexEngine: called with incompatible input array");
        }

	if (out.length != 2*w*h*d) {
	    throw new IllegalArgumentException(
            "FFTWRealToComplexEngine: called with incompatible out array");
        }

	setDimensions(iw,w,h,d);       // Set dimensional
	setInputBuffer(in);
	setOutputBuffer(out);
    }



    /**       Form a two-dimensional ComplexToReal Engine
     *        specified input and output buffers.
     *        @param w the width
     *        @param h the height
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexToRealEngine(int w, int h,
				   double[] in,
				   double[] out) {
	this(w,h,1,in,out);           // Depth is 1
    }


    /**       Form a one-dimensional ComplexToReal Engine
     *        specified input and output buffers.
     *        @param w the width
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexToRealEngine(int w, 
				   double[] in,
				   double[] out) {
	this(w,1,1,in,out);           // Height and Depth are  1
    }

    /**      Form a three-dimensional ComplexToReal Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *        @param w the width
     *        @param h the height
     *        @param d the depth
     */
    public FFTWComplexToRealEngine(int w, int h, int d) {
	int iw = (w/2 + 1);               // Output width
	setDimensions(iw,w,h,d);
	setInputBuffer(new double[2*iw*h*d]);     // input buffer in real space
	setOutputBuffer(new double[w*h*d]);       // Hermition output buffer
    }
    
    /**      Form a two-dimensional ComplexToReal Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *       @param w the width
     *       @param h the height
     */
     public FFTWComplexToRealEngine(int w, int h) {
	 this(w,h,1);                  // Depth is 1
     }

    
    
    /**      Form a one-dimensional ComplexToReal Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *        @param w the width
     */
     public FFTWComplexToRealEngine(int w) {
	 this(w,1,1);                  // Height and Depth are 1
     }


    /**    Method to set the an input buffer element with a double
     *     @param i the element index
     *     @param a the value
     */
    public void setInputReal(int i, double a) {
	ArrayUtil.setComplex(inputBuffer,i,a,0.0);
    }
    

    /**    Method to set a complex elemment in the input buffer
     *     @param i the element index
     *     @param a the real input value
     *     @param b the imaginary input value
     */
    public void setInputComplex(int i, double a, double b) {
	ArrayUtil.setComplex(inputBuffer,i,a,b);
    }


    public double getInputReal(int i) {
	return Double.NaN;
    }

    /**    Method to get a specifed element if the input buffer
     *     @param i the element index
     *     @return <code>Complex</code> the value of the element.
     */
    public Complex getInputComplex(int i) {
	return ArrayUtil.getComplex(inputBuffer,i);
    }

    /**   Method to set the an element in the output Real array
     *    with a double.
     *    @param i the element index
     *    @param a the real value
     */ 
    public void setOutputReal(int i, double a) {
	outputBuffer[i] = a;
    }

    
    public void setOutputComplex(int i, double a, double b) {
	outputBuffer[i] = a;
    }

    /**   Method to get an element real output buffer
     *    @param i the element index
     *    @return <code>Complexl</code> the elemtn value
     */
    public double getOutputReal(int i) {
	return outputBuffer[i];
    }

    public Complex getOutputComplex(int i) {
	return new Complex(outputBuffer[i]);
    }


    public void makePlan() {}

}

	

