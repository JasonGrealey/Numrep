package jfftw;

/**        Class to form Complex Engine with complex input and output buffer
 *         for taking either forward of backward FFTs
 */

public class FFTWComplexEngine extends FFTWEngine {

    protected int sign;
    protected FFTWComplex fft = new FFTWComplex(this);


    /**       Form a three-dimensional ComplexEngine of specified size with
     *        specified input and output buffers.
     *        @param w the width
     *        @param h the height
     *        @param d the depth
     *        @param in the input buffer
     *        @param out the output buffer
     *        @param sign direction of the transform
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexEngine(int w, int h, int d,
			     double[] in, 
			     double[] out,
			     int sign) {
	//      Basic sanity checks !!!
	
	if (in == null || out == null ) {
	    throw new NullPointerException(
	   "FFTWComplexEngine: called with null data array.");
	}
	int size = 2*w*h*d;
	if (in.length != size || out.length != size) {
	    throw new IllegalArgumentException(
	    "FFTWComplexEngine: called with incompatible array lengths");
	}
	
	setDimensions(w,w,h,d);               // Set internal dimensions
	setInputBuffer(in);                   // Set input buffer
	setOutputBuffer(out);                 // Set output buffer
	setSign(sign);                        
    }

    /**       Form a two dimensional ComplexEngine of specified size with
     *        specified input and output buffers.
     *        @param w the width
     *        @param h the height
     *        @param in the input buffer
     *        @param out the output buffer
     *        @param sign direction of the transform
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexEngine(int w, int h, 
			     double[] in, double[] out,
			     int sign) {
	this(w,h,1,in,out,sign);     // Use general method to do the work
    }

    /**       Form a one dimensional ComplexEngine of specified size with
     *        specified input and output buffers.
     *        @param w the width
     *        @param in the input buffer
     *        @param out the output buffer
     *        @param sign direction of the transform
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWComplexEngine(int w, double[] in, 
			     double[] out,
			     int sign) {
	this(w,1,1,in,out,sign);         // Use general metho to do the work
    }
   

    /**       Form a three dimensional ComplexEngine of specified size
     *        The input and output buffers will be automatically
     *        created.
     *        @param w the width
     *        @param h the height
     *        @param d the depth
     *        @param sign direction of the transform
     *        @param overwrite if true then input and output buffer
     *        will be the same array, if false they will the seperate
     *        arrays.
     */  
    public FFTWComplexEngine(int w, int h, int d, int sign, 
			     boolean overwrite) {
	setDimensions(w,w,h,d);              // Set internal dimensions
	int size = 2*w*h*d;    
	setInputBuffer(new double[size]);    // Make input buffer  
	if (overwrite) {                     // On inplane input = output
	    setOutputBuffer(getInputBuffer());
	}
	else {                               // else make a output buffer
	    setOutputBuffer(new double[size]);
	}
	setSign(sign);
    }
    
    /**       Form a two-dimensional ComplexEngine of specified size
     *        The input and output buffers will be automatically
     *        created.
     *        @param w the width
     *        @param h the height
     *        @param sign direction of the transform
     *        @param overwrite if true then input and output buffer
     *        will be the same array, if false they will the seperate
     *        arrays.
     */  
    public FFTWComplexEngine(int w, int h, int sign, boolean overwrite) {
	this(w,h,1,sign,overwrite);
    }

    /**       Form a one-dimensional ComplexEngine of specified size
     *        The input and output buffers will be automatically
     *        created.
     *        @param w the width
     *        @param sign direction of the transform
     *        @param overwrite if true then input and output buffer
     *        will be the same array, if false they will the seperate
     *        arrays.
     */
    public FFTWComplexEngine(int w, int sign, boolean overwrite) {
	this(w,1,1,sign,overwrite);
    }


    /**          Method to set the sign to FORWARD of BACKWARD (this is
     *           only needed for Complex Engine.
     */
    public void setSign(int s) {
	sign = s;
    }


    public double getInputReal(int i) {
	return Double.NaN;
    }

    /**         Method to get an input element as a Complex 
     *          @param i the element index
     *          @return <code>Complex</code> the element.
     */
    public Complex getInputComplex(int i) {
	return ArrayUtil.getComplex(inputBuffer,i);
    }

    /**         Method to get an output element as a Complex
     *          @param i the element index
     *          @return <code>Complex</code> the element
     */ 
    public Complex getOutputComplex(int i) {
	return ArrayUtil.getComplex(outputBuffer,i);
    }

    /**        Method to set a specifeid element od the complex
     *         input array with real, it will set the real part
     *         to specifed value and the inaginary to zero.
     *         @param i the index
     *         @param a the realk value
     */
    public void setInputReal(int i, double a) {
	setInputComplex(i,a,0.0);
    }

    /**         Method to set the specifed element of the
     *          input complex with two doubles.
     *          @param i the elemnt index
     *          @param a the real value
     *          @param b the imaginary value
     */
    public void setInputComplex(int i, double a, double b) {
	ArrayUtil.setComplex(inputBuffer,i,a,b);
    }
    
    /**        Method to set a specifeid elemment of the complex
     *         output array with real, it will set the real part
     *         to specifed value and the inaginary to zero.
     *         @param i the index
     *         @param a the real value
     */
    public void setOutputReal(int i, double a) {
	setOutputComplex(i,a,0.0);
    }

    

    /**         Method to set the specifed element of the
     *          output complex with two doubles.
     *          @param i the elemnt index
     *          @param a the real value
     *          @param b the imaginary value
     */
    public void setOutputComplex(int i, double a, double b) {
	ArrayUtil.setComplex(outputBuffer,i,a,b);
    }




    /**      Method to make the current plan
     */
    public void makePlan() {
	plan = nativeComplexPlan(inputWidth,height,depth,
				 inputBuffer,
				 outputBuffer,
				 sign,
				 getPlanFlag());
    }
				 

    /**     Native method to bbuild a plan returns the plan number
     */
    private native int nativeComplexPlan(int w, int h, int d,
					 double[] in,
					 double[] out,
					 int dirn,
					 int flag);

}



	    
