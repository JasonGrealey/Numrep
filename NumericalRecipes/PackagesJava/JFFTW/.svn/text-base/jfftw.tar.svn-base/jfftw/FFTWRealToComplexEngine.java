package jfftw;

/**    Class to for a (forward), Real to hermition complex FFT engine
 *     with a real input buffer and hermition complex output buffer.
 *     Note since there are in gerenal of diffent size, then they
 *     callon be the same array.
 */

public class FFTWRealToComplexEngine extends FFTWEngine {

    protected FFTWReal fft = new FFTWReal(this);

    /**        Form a three-dimensional RealToComplex Engine
     *        specified input and output buffers.
     *        @param w the width
     *        @param h the height
     *        @param d the depth
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWRealToComplexEngine(int w, int h, int d,
				   double[] in,
				   double[] out) {
	//       Basic sanity checks!!
	if (in == null || out == null || in == out ) {
            throw new NullPointerException(
 "FFTWRealToComplexEngine: called with null data array or same in/out arrays");
        }

	if (in.length != w*d*h) {
	    throw new IllegalArgumentException(
            "FFTWRealToComplexEngine: called with incompatible input array");
        }

	int ow = (w/2 + 1);               // Output width

	if (out.length != 2*ow*h*d) {
	    throw new IllegalArgumentException(
            "FFTWRealToComplexEngine: called with incompatible out array");
        }

	setDimensions(w,ow,h,d);       // Set dimensional
	setInputBuffer(in);
	setOutputBuffer(out);
    }



    /**       Form a two-dimensional RealToComplex Engine
     *        specified input and output buffers.
     *        @param w the width
     *        @param h the height
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWRealToComplexEngine(int w, int h,
				   double[] in,
				   double[] out) {
	this(w,h,1,in,out);           // Depth is 1
    }


    /**       Form a one-dimensional RealToComplex Engine
     *        specified input and output buffers.
     *        @param w the width
     *        @param in the input buffer
     *        @param out the output buffer
     *        @throws NullPointerException if array null
     *        @throws IllegalArgumentException if array lengths
     *        do not match size.
     */
    public FFTWRealToComplexEngine(int w, 
				   double[] in,
				   double[] out) {
	this(w,1,1,in,out);           // Height and Depth are  1
    }

    /**      Form a three-dimensional RealToComplex Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *        @param w the width
     *        @param h the height
     *        @param d the depth
     */
    public FFTWRealToComplexEngine(int w, int h, int d) {
	int ow = (w/2 + 1);               // Output width
	setDimensions(w,ow,h,d);
	setInputBuffer(new double[w*h*d]);     // input buffer in real space
	setOutputBuffer(new double[2*ow*h*d]);  // Hermition output buffer
    }
    
    /**      Form a two-dimensional RealToComplex Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *        @param w the width
     *        @param h the height
     */
     public FFTWRealToComplexEngine(int w, int h) {
	 this(w,h,1);                  // Depth is 1
     }

    
    
    /**      Form a one-dimensional RealToComplex Engine
     *       whithe input and and output baffer are aoutomatically
     *       created. Not they will always be different arrays since
     *       in general they will NOT be the same size.
     *        @param w the width
     */
     public FFTWRealToComplexEngine(int w) {
	 this(w,1,1);                  // Height and Depth are 1
     }


    /**    Method to set the an input buffer element with a double
     *     @param i the element index
     *     @param a the value
     */
    public void setInputReal(int i, double a) {
	inputBuffer[i] = a;
    }
    
    /**     Method to set an input element with a Complex, but since
     *      the input is real only a warning message is generated
     *      @param i the element index
     *      @param a the real value
     *      @param b the imaginary value
     */
    public void setInputComplex(int i, double a, double b) {
	errorStream.println(
    "FFTWRealToComplex.setInputComplex: using real part only");
	setInputReal(i,a);
    }


    /**     Method to get an input element as a real 
     *      @param i the element index
     *      @return <code>double</code> the element value
     */
    public double getInputReal(int i) {
	return inputBuffer[i];
    }

    /**    Method to get an element of the Real input buffer as a Complex
     *     @param i the element index
     */ 
    public Complex getInputComplex(int i) {
	return new Complex(inputBuffer[i]);
    }

    /**   Methed to set the an element in the outpout Complex array
     *    with two doubles.
     *    @param i the element index
     *    @param a the real value
     *    @param b the imaginary value
     */ 
    public void setOutputComplex(int i, double a, double b) {
	ArrayUtil.setComplex(outputBuffer,i,a,b);
    }

    
    /**   Method to get an element  of the Complex output buffer
     *    as a Complex
     *    @param i the element index
     *    @return <code>Complexl</code> the elemtn value
     */
    public Complex getOutputComplex(int i) {
	return ArrayUtil.getComplex(outputBuffer,i);
    }


    public void makePlan() {}


}

	

