package jfftw.test;
import jfftw.*;
import ptolemy.plot.*;
/**     One dimensional test programme to form a top hat,
 *      form it real FFT. It then plots the modulus using ptplot
 *      @author Will Hossack, The University of Edinburgh
 */
public class OneDimensionalReal {
    public static void main(String args[]) {
	int len = 500;                    // length of array
	int w = 10;                       // width of top-hat

	//          Make a real signal with centred top-hat of
	//          unit height.
	double[] r = new double[len];
	for(int i = (len - w)/2; i <= (len + w)/2; i++) {
	    r[i] = 1.0;
	}

	// FFTW.throwLoadException = false;

	System.out.println("Load exceptions is " + 
			   FFTW.throwLoadException);

	FFTWReal fft = new FFTWReal();        // Make fft object

	//          Take forward fft to interleaved Complex
	//          array.
	double[] ft = fft.oneDimensionalForward(r);

	//            Plot out the modulus, note the length
	//            of the hermition array.
	Plot plot = new Plot();
	for(int i = 0; i < len/2 + 1; i++) {
	    double y = ArrayUtil.getComplex(ft,i).modulus();
	    plot.addPoint(0,(double)i,y,true);
	}

	//          make ptframe and display result
	PlotFrame frame = new PlotFrame("Modulus",plot);
	frame.setSize(600,400);
	frame.setVisible(true);

	
    }
}
