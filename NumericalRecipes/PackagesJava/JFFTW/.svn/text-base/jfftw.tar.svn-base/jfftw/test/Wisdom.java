import jfftw.*;
import java.io.*;


public class Wisdom {
    public static void main(String args[]) {
	
	FFTW f = new FFTW();
       	String w = FFTW.readWisdom(new File("wisdom-E6700"));

	System.out.println(w);

	System.out.println(" Wisdom load is : " + f.loadWisdomFromString(w));

	String wisdom = f.getWisdom();
	
	System.out.println("Length is " + wisdom.length());
	System.out.println(wisdom);


	//FFTW.writeWisdom(wisdom,new File("test"));	

    }



}
