import jfftw.*;

/**       Test the ComplexEngine class.
 */

public class EngineTest {

    public static void main(String args[]) {

	FFTWComplexEngine ce = new FFTWComplexEngine(2048,FFTW.FORWARD,false);
	
	System.out.println("Engine " + ce);

	for(int i = 0; i < ce.getInputWidth(); i++) {
	    ce.setInputComplex(i,Math.random(),0.0);
	}
	

	ce.update();

	

    }
}
