package jfftw.test;
import jfftw.*;
/**     Simple test program to test two-dimensional FFTs using the
 *      FFTComplex class and the ArrayUitil access classes to 
 *      set/get complex values from the interleaved arrays.
 *      @author Will Hossack, The Univesrity of Edinburgh.
 */

public class TwoDimensions extends Object {
    public static void main(String args[]) {

	int width = 200;                  // Size of array
	int height = 300;

	//             Make complex array (twice the size)
	double[] data = new double[2*width*height];

	//        Fill both parts with random using the ArrayUtil
	//        class to do the indexing.
	for(int i = 0; i < width*height; i++) {
	    ArrayUtil.setComplex(data,i,Math.random(),Math.random());
	}

	//          Form the FFTWComplex do do the work
	FFTWComplex fft = new FFTWComplex();


	//    Take out-of -place forward fft, does not alter the data[]
	//    array.
	double[] ft = fft.twoDimensional(width,height,data,1,false);
       
	//    Take in place backwords fft  
	fft.twoDimensional(width,height,ft,-1,true);
	
	// Normalise...   (no default normalsiation when using FFTW)
	
	ArrayUtil.mult(ft,1.0/(width*height));

	//   Check difference by comparing the modulus of each element.
	double diff = 0;
	for(int i = 0; i < width*height; i++) {
	    double d = ArrayUtil.getComplex(data,i).modulus() -
		ArrayUtil.getComplex(ft,i).modulus();
	    diff += Math.abs(d);
	}

	//         Print out the difference.... shoul be small.
	System.out.println("Difference is : " + diff);


	

    }
}