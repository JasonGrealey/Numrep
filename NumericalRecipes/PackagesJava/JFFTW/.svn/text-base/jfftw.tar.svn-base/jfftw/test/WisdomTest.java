import jfftw.*;
/**       Test program to open FFTW and read a specified Wisdom
 *        file.
 */

public class WisdomTest {
    public static void main(String args[]) {
	
	if (args.length < 1) {
	    System.err.println("Usage: java WisdomTest file");
	}

	//            Form FFTW with specifed wisdon file (by name)
	FFTW fft = new FFTW(args[0]);

	//           Print to standard output.
	System.out.println(fft.getWisdom());
    }
}