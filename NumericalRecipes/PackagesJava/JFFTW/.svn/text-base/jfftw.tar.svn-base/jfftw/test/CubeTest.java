package jfftw.test;
import jfftw.*;
/**    Test program for cube (three-D real) FFTW using the
 *     lowlevel FFTWReal interface.
 *     @author Will Hossack, The University of Edinburgh
 */
public class CubeTest {
    public static void main(String args[]) {

	int width = 256;
	int height = 256;
	int depth = 128;

	//           Make a double array of currect size in real space
	double d[]= new double[width*height*depth];
	System.out.println("Length of initial array is " + d.length);

	//          Set elements to random number between 0-10

	for(int i = 0; i < d.length; i++) {
	    d[i] = 10.0*Math.random();
	}

	//          Make the FFTWReal class to do the work
	FFTWReal fftw = new FFTWReal();

	//          Take out of place forward FFT, 
	//          return a double[] which hold Hermition 
	//          complex array in interleaved format.
	double ft[] = fftw.threeDimensionalForward(width,height,depth,d);
	System.out.println("Length of ft is " + ft.length);

	//          Reconstruct, again out of place, back to real space
	double recon[] = fftw.threeDimensionalBackward(width,height,depth,ft);
	System.out.println("Length of reconstruction is " + recon.length);

	//          Scale the inverse by 1/N to (no scale in FFTW)
	//          Use ArrayUtil class to do the work.
	ArrayUtil.mult(recon,1.0/(width*height*depth));

	//          Calcualte diff square between d and recon
	double diff = 0.0;
	for(int i = 0; i < recon.length; i++) {
	    diff += Math.abs(d[i] - recon[i]);
	}

	//          Print out the difference
	//          (should be very small, about e-8)
	System.out.println("Difference is " + diff);


    }
}
