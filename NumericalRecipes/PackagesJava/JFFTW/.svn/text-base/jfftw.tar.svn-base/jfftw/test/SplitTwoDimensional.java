package jfftw.test;
import jfftw.*;

/**     Test programme to test the interleaved and split 
 *      array methods in two dimensions. 
 *      @author Will Hossack, The University of Edinburgh
 */
public class SplitTwoDimensional {
    public static void main(String args[]) {

	int width = 400;                // Non square array
	int height = 300;

	double[] rp = new double[width*height];  // Make real part.
	//      Fill the real space with random numbers
	for(int i = 0; i < rp.length; i++) {
	    rp[i] = Math.random();
	}

	//         Make interleaved array with null imaginary 
	//         The imaginary defaults to zero
	double[] dataInterleave = ArrayUtil.interleave(rp,null);
	
	//        Make a split array with specifed real and
	//        null imaginary, which defaults to zero
	double[][] dataSplit = ArrayUtil.split(rp,null);

	//         Make Complex FFT
	FFTWComplex fft = new FFTWComplex();

	//         FFT both formats, one in-place, other out-of-place
	//
	dataInterleave = fft.twoDimensional(width,height,dataInterleave,1,true);
	dataSplit = fft.twoDimensional(width,height,dataSplit,1,false);

	//         Form difference bwteeen modulus square (should be zero).
	double diff = 0.0;
	for(int i = 0; i < width*height; i++) {
	    double a = ArrayUtil.getComplex(dataInterleave,i).modulusSq();
	    double b = ArrayUtil.getComplex(dataSplit,i).modulusSq();
	    diff += (a - b);
	}
	System.out.println("Difference is " + diff);
    

    }
}
	