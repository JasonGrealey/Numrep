package jfftw.demo;
import jfftw.*;
import ptolemy.plot.*;

/**     Test program to form a two-dimensional checkerboard in
 *      a complex two-dimensional data array.  The log power spectrum
 *      in formed in a real data array and the horizontal and vertical
 *      lines theorugh the centre and plotted using ptplot.
 *      <p>
 *      Try:  java ChekerBoard 4 8 512
 *      <p>
 *      forms a 4 x 8 pixel checker board in a 512 x 512 array.
 *      <p>
 *      Note if the image size of not a multiple of the checkerboard
 *      strange aliasing results occur (which is actually correct)
 *      @author Will Hossack, 2008
 *
 *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

public class CheckerBoard {
    public static void main(String args[]) {

	//         Check for three parameters
	if (args.length < 3) {
	    System.out.println("Usage: java CheckerBoard xsize ysize size");
	    System.exit(1);
	}

	//          And read them...
	int xSize = Integer.parseInt(args[0]);
	int ySize = Integer.parseInt(args[1]);
	int n = Integer.parseInt(args[2]);

	//         Make a real data array of size nxn
	DataArray im = new ComplexDataArray(n,n);	
	System.out.println(im);           // Information.


	//             Make a two-dimensional checkerboard with 1:1
	//             mark to space ratio.
	for(int j = 0; j <  im.getHeight(); j++) {
	    boolean bj = (j%ySize) < ySize/2;
	    for(int i = 0; i < im.getWidth(); i++) {
		boolean ib = (i%xSize) < xSize/2;
		if (bj && ib) im.setDouble(i,j,1.0);
	    }
	}

	//            Take log power spectrum (centred FT)
	RealDataArray power = im.powerSpectrum(true);
	System.out.println(power);             // Information

	//            Create a plot
	Plot plot = new Plot();
	

	//              Extract the vertical line through centre
	for(int i = 0; i < power.getWidth(); i++) {
	    int k = i - power.getWidth()/2;
	    plot.addPoint(0,(double)k,power.getDouble(i,power.getHeight()/2),
			  true);
	}

	//              Extract the horizontal line through centre
	for(int j = 0; j < power.getHeight(); j++) {
	    int k = j - power.getHeight()/2;
	    plot.addPoint(1,(double)k,power.getDouble(power.getWidth()/2,
						      j),true);
	}

       //           Display in frame of size 600,400 pixels
        PlotFrame frame = new PlotFrame("Log Modulus",plot);
        frame.setSize(600,400);
        frame.setVisible(true);



	

    }
}
	
