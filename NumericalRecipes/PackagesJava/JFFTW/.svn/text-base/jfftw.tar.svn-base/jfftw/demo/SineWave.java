package jfftw.demo;
import jfftw.*;
import ptolemy.plot.*;

/**     Test program to take Complex FT of a one-dimensional sin
 *      wave with one frequency in real and one in imaginary. 
 *      The modulus of the centreFourier() is plotted via ptplot.
 *      <p>
 *      Try:   java SineWave 0.3 0.4
 *      
 *      @author Will Hossack, 2008
 *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
public class SineWave {
    public static void main(String args[]) {

	final int n = 200;              // Length of signal

	//         Check the arguments have been passed...
        if (args.length < 2) {
            System.out.println("Usage: SineWave realfreq imagfreq");
            System.exit(1);
        }

	//           Read the two arguments from the command line
        double realFreq = Double.parseDouble(args[0]);
	double imagFreq = Double.parseDouble(args[1]);
        System.out.println("Real Freq : " + realFreq + " Imag Freq : " +
			   imagFreq);

	//         Make of ComplexDataArray of length n
        DataArray signal = new ComplexDataArray(n);

	//        Fill with the two frequencies one in the real
	//        the other in the imaginary part
        for(int i = 0 ; i < signal.getWidth(); i++) {
            double tr = 2.0*Math.PI*realFreq*i;    // Real freq
	    double ti = 2.0*Math.PI*imagFreq*i;    // Imag freq
	    //         cos to real, sin to imaginary
            signal.setComplex(i,Math.cos(tr),Math.sin(ti));
        }

	//          Take the centreFourier
        signal.centreFourier();


	//          Form a RealDataArray of same size where each
	//          element is given by MODULUS of the complex
	DataArray modulus = signal.getRealDataArray(Complex.MODULUS);


	/*          Plot out the result using ptplot. 
	 *          Note we have taken a centred FFT so k runs from
	 *          -w/2 -> w/2 - 1
	 */
        Plot plot = new Plot();
        for(int i = 0; i < modulus.getWidth(); i++) {

	    int k  = i - modulus.getWidth()/2;      // True k value
	                                           // Add pt to graph
            plot.addPoint(0,(double)k,modulus.getDouble(i),true);
        }


	//           Display in frame of size 600,400 pixels
        PlotFrame frame = new PlotFrame("Modulus",plot);
        frame.setSize(600,400);
        frame.setVisible(true);

    }
}
