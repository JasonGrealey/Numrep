import jfftw.*;

/**      Test programme to test the speed difference between 
 *       reallocation of memory in real FFT using the
 *       FFTWReal interface.    
 */


public class OneDimensionFast {

    public static void main(String args[]) {

	if (args.length < 2) {
	    System.out.println("Usage: java OneDimensionalFast size n");
	    System.exit(1);
	}

	//         Read real length and length of test loop.
	int realLength = Integer.parseInt(args[0]);
	int n = Integer.parseInt(args[1]);

	int complexLength = 2*(realLength/2 + 1);

	System.out.println("Real length is : " + realLength +
			   " Complex length is : " + complexLength);

	//            Make real and complex storage
	double[] realArray = new double[realLength];
	double[] complexArray = new double[complexLength];

	//            Make the FFTWReal object
	FFTWReal fft = new FFTWReal();
	
	//            Start the nano-sec timer
	long startTime = System.nanoTime();


	//            Go round taking FFTreals
	for(int k = 0; k < n; k++) {
	    
	    // for(int i = 0; i < realLength; i++) {
	    //	realArray[i] = Math.random();
	    //}

	    //               Forward using pre-allocated memory 
	    complexArray = fft.oneDimensionalForward(realArray,complexArray);

	    //               Forward using auto memory allocation
	    //complexArray = fft.oneDimensionalForward(realArray);

	    //               Backwards using pre-alloated memory
	     realArray = fft.oneDimensionalBackward(complexArray,realArray);

	    //               Forward using auto memory allocation
	    //realArray = fft.oneDimensionalBackward(complexArray);
	    
	}

	long estimatedTime = System.nanoTime() - startTime;
	
	System.out.println("Estimated time is : " + 
			   (double)estimatedTime/1.0E9);
    }
}
