package jfftw.demo;
import jfftw.*;

/**   Simple test program to form sin function in ComplexDataArray, 
 *    take it FFT twice and compare with the original. 
 *    Output is single text; no graphics used.
 *
 *    @author Will Hossack, 2008
 *     
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
public class OneDimensionDemo extends Object {

    public static void main(String args[]) {

	//           Check what parameters have been passed
	if (args.length < 1) {
	    System.out.println("Usage: java OneDimensionTest length");
	    System.exit(1);
	}
	
	//           Read length from command line
	int n = Integer.parseInt(args[0]);
	double freq = 0.1;

	//           Make a one dimensional Complex signal of
	//           required length
	ComplexDataArray signal = new ComplexDataArray(n);

	//            Fill signal with complex signal of form
	//            [0.5 + sin(theta) , cos(2*theta)]
	//            use getWidth() to the width and
	//            setComplex() to set the values.
	for(int i = 0; i < signal.getWidth(); i++) {
	    double theta = 2.0*Math.PI*freq*i;        
	    signal.setComplex(i,0.5 + Math.sin(theta),Math.cos(2.0*theta));
	}

	System.out.println(signal);         // Basic Information
	
	//      Calculate power (sum of mod squared)
	System.out.println("Real space power is : " + signal.power());

	//            Make clone of signal as reference (also complex)
	ComplexDataArray reference = signal.clone();

	//            Take forward FFT of the signal. 
	signal.fourier();

	System.out.println(signal);        // Information

	//       Calcuate Fourier power. It SHOULD be the same at
	//       real space, but normalisation only occurs on
	//       inverse so it will be n*realPower
	System.out.println("Unnormalised Fourier space power is : " 
			   + signal.power());
	
	//            Take second fouier. The signal is in Fourier space
	//            so fourier() will automatically take the inverse FFT
	//            and also normalise the data on inverse.
	signal.fourier();

	System.out.println(signal);        // Information

	//         Form modulus difference between signal/reference
	//         should be zero (or very close)
	double diff = 0.0;

	for(int i = 0; i < signal.getWidth(); i++) {
	    
	    //        Get signal - reference (both as Complex)
	    Complex d = signal.getComplex(i).minus(reference.getComplex(i));

	    //        Take sum of modulus squared
	    diff += d.modulus();
	}

	System.out.println("Absolute modulus difference is : " + diff);

    }
}