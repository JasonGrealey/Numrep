import jfftw.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;

/**    Demo program to read in an image into a standard Java
 *     BufferedImage, take its power spectrum and output it
 *     as a jpeg file. There is no graphical display included
 *     and the output is to a fixed file called "power.jpeg".
 * 
 *     @author Will Hossack, 2008
 *
 *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 */          

public class ImageDemo {
    
    public static void main(String args[]) throws IOException{

	//         Basic sanity check
	if (args.length < 1) {
	    System.out.println("Usage: java ImageDemo image");
	    System.exit(1);
	}

	//        Read image from file to buffered image
	//        using javax.imageio.Imageio.read static method.
	//        This will support (typically), jpeg,gif,jpg image formats.
	//        	
	BufferedImage bi = ImageIO.read(new File(args[0]));
	System.out.println("Image size is " + bi.getWidth() + " by " +
			   bi.getHeight());


	//        Form a ComplexDataArray from the Buffered image
	//        with default plane. This will be 0 for momochrome
	//        images and 1 (or green) for full colour images.
	//        
	//        The image will be placed in the REAL components of
	//        the complex image.
	//

	DataArray im = new ComplexDataArray(bi,-1);

	//         Try replacing this with:
	// 
	//      DataArray im = new RealDataArray(bi,-1);
	//         
	//         make sure you understand the output.
	//
	System.out.println("Image info: " + im);

	//        Take the centred FFT in two dimenions. Provided the
	//        image is of even size, this will place the DC at the
	//        centre of the output.
	im.centreFourier();

	//        Form the Power spectrum by getting the ft as a
	//        ReadDataArray using the LOG_POWER conversions flag.
	DataArray ps = im.getRealDataArray(Complex.LOG_POWER);
	System.out.println("Power spectum: " + ps);

	//        End of jfftw demo.... the next bit it forming
	//        a byte buffered image so it can be output.

	//        Find the max value of the ps image
	//        This is needed for scaling.
	//        Note its a power spectrum so it must be all positive
	//        so we can take the min as zero.
	double max = 0.0;

	for (int i = 0; i < ps.getWidth()*ps.getHeight(); i++) {
	    double v = ps.getDouble(i);    // One-D access goes a bit quicker
	    if (v > max) max = v;
	}

	//         Form a new BYTE BufferedImage of the correct size. 
	BufferedImage psImage = 
	    new BufferedImage(ps.getWidth(),
			      ps.getHeight(),
			      BufferedImage.TYPE_BYTE_GRAY);
	
	//         Get its raster so we can write to it
	WritableRaster raster = psImage.getRaster();


	//         Fill up the raster point at a time while scaling the
	//         output values into the range 0 -> 255 to match the
	//         BYTE image format.
	for(int j = 0; j < ps.getHeight(); j++) {
	    for(int i = 0; i < ps.getWidth(); i++) {
		
		//           Get value and scale to 0 -> 255.
		double p = 255.0*ps.getDouble(i,j)/max;

		//           Set the sample value in the raster. 
		//           For momochrome image data is in bank 0
		raster.setSample(i,j,0,p);
	    }
	}


	//         Write the power spectrum out to a Jpeg file
	//         called ``power.jpeg'' using the standard
	//         Java ImageIO static image writer.

	if (ImageIO.write(psImage,"jpeg",new File("power.jpeg")) ) {
	    System.out.println("Output written to `power.jpeg'");
	}
	else {
	    System.out.println("Failed to write final jpeg image");
	}

	
	
    }
}
