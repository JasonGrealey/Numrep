package jfftw.demo;
import jfftw.*;

/**     Simple test program for two dimensional Complex FFts. 
 *      Program forms 2-D complex DataArray filled with Randoms
 *      take two centered FFT and compared to reference copy of original.
 *
 *      In you run this with VERY large arrays you will run out of 
 *      default heap memory. If this happens (on Linux) use the
 *      -Xmx<nnn>M flag, so 
 *      <p>
 *      java -Xmx512M TwoDimensionalDemo 4096 4096
 *      <p>
 *      will (eventually!!!) take a 4096x4096 complex FFT, provided
 *      your system has enough physical memory that it does not 
 *      swap-thrash its self into the ground!!! 
 * 
 *      @author Will Hossack, 2008
 *
 *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 * 
 */

public class TwoDimensionDemo {
  
    public static void main(String args[]) {

	//                 Need two arguments (width and height)
	if (args.length < 2) {
	    System.out.println("Usage: java TwoDimensionTest w h");
	    System.exit(1);
	}

	//          Get width and height from command line.
	int width = Integer.parseInt(args[0]);
	int height = Integer.parseInt(args[1]);

	//        Make an two-dimensional real data array to be used as the
	//        reference array.
	DataArray ref = new RealDataArray(width,height);

	//        Fill real parts with randoms using two-dimensional
	//        access and the standard Java random number generator
	for(int j = 0; j < ref.getHeight(); j++) {
	    for(int i = 0; i < ref.getWidth(); i++) {
		ref.setDouble(i,j,Math.random());
	    }
	}
	System.out.println("Reference array : " + ref);   // Information.

	//        Make the complex data array taking the real ref
	//        array as its Real parts, the imaginary will default to
	//        zero.
	DataArray im = new ComplexDataArray(ref);
	
	System.out.println("Complex array: " + im);             // Information.

	//            Take centred FFT
	//            If sizes not even, you will get an warning message
	//            and standard FFT will be taken (but it still works)
	im.centreFourier();
	System.out.println("After fourier " + im);             // Information.

	//            Take second centred FFT (so should get back
	//            to where we started due to default auto-normalisation)
	im.centreFourier();
	System.out.println("After second fourier " + im); // Information.

	//           Take difference between im and ref using getDouble()
	//           access scheme.

	//           Set default getDouble conversion to take the 
	//           REAL part only.
	im.setConversion(Complex.REAL);  

	double diff = 0.0;

     	//           Form modulus difference between the REAL part
	//           of the twice FFT(ed) complex array and real ref.
	//           using two-dimensional access.
	for(int j = 0; j < im.getHeight(); j++) {
	    for(int i = 0; i < im.getWidth(); i++) {
		diff += Math.abs(im.getDouble(i,j) - ref.getDouble(i,j));
	    }
	}
	//          Print of difference (should be small !!!)
	System.out.println("Difference is : " + diff);
				 
	
    }
}
