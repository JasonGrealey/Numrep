/**     Simple demo of the Complex class used in jfftw to used to
 *      handle Complex numbers. The Complex class has all expected
 *      methods and supports 2 and 3 operator arithmetic.
 *
 *      @author Will Hossack, 2008
 *
 *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *       
 *
 */
package jfftw.demo;
import jfftw.*;                             // Import jfftw classes

public class ComplexDemo {

    public static void main(String args[]) {

	Complex a = new Complex(2.0,3.0);   // Declare a complex preset
	Complex b = new Complex();          // Declare default 0,0
	b.setExpi(0.2);                     // set to expi(0.2)

	Complex c = a.clone();              //  Take a clone of a. 

	//             Print out some value values
	System.out.println("Value of a is : " + a);   // default toString()
	System.out.println("b has modulus : " + b.modulus() +
			   " and phase " + b.phase());

	//             Get real/imaginary parts of c 
	//             via getters and print them.
	double x = c.getReal();
	double y = c.getImag();
	System.out.println("Real part is : " + x + " Imaginary is : " + y);
	

	//             Some thee-operator arithmetic which can be chained 
	Complex d = a.mult(b).plus(2.5,4.0);

	//             And some two-operator arithmetic 
	d.multBy(c);         // Changes d ``in place''

	//             Printout the result
	System.out.println("Value of d is " + d);
	System.out.println("and has modulus squared " + d.modulusSq());


	//           Some more advanced things.

	a.setPolar(3.0,0.35);         // set to 3.0 exp(i 0.35)
	b.setRandomPhase(5.0);        // set to 5.0 exp(i rand)
                                      // where rand between 0->2pi

	c = a.over(b);                // Complex fraction a/b
	System.out.println("Fractions is : " + c); // Different each call
 

	//           The getDouble(int flag ) method to get
	//           the a double value. The choice is
	//           REAL, IMAG, MODULUS, MODULUS_SQUARED, PHASE, LOG_POWER
	double m = c.getDouble(Complex.LOG_POWER);
	System.out.println("Log power of c is : " + m);
	


	//           Public access to real/imag
	System.out.println(".. direct access gives\n real " + c.r + 
			   "\n and imaginary " + c.i);
    }
}
