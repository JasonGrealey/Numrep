package jfftw;

/**     Class to implement a FFT Engine based on FFTW. The ideal of an
 *      Engine is that there is a fixed size input and output buffer
 *      with the input being transfored to the output on demand.
 *      This class, and it extending classes, are designed to implement
 *      for example a "real-time" spectrum analyser. 
 *
 *      @author Will Hossack, 2008
 *
 *          *
 *    This file is part of jfftw.
 *
 *    Jfftw is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Jfftw is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Jfftw.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */

public abstract class FFTWEngine extends FFTW {

    /**         Plan id 
     */
    protected int plan = -1;

    /**          Width of the input data
     */
    protected int inputWidth;

    /**          Width of the output data 
     */
    protected int outputWidth;

    /**           Height of the data
     */
    protected int height;

    /**            Depth of the data
     */
    protected int depth;

    /**       The input buffer of the Engine
     */
    protected double[] inputBuffer;

    /**       The output buffer of the Engine
     */
    protected double[] outputBuffer;


    /**     Method to set the input buffer to specifed array
     *      @param in the input buffer.
     */
    public void setInputBuffer(double[] in) {
	inputBuffer = in;
    }

    /**     Method set the input buffer to new <code>double[]</code>
     *      array of specified length. Any previous buffer will be lost.
     *      @param size length of input buffer.
     */
    public void setInputBuffer(int size) {
	inputBuffer = new double[size];
    }

    /**     Method to get the input buffer
     *      @return <code>double[]</code> the input buffer
     */
    public double[] getInputBuffer() {
	return inputBuffer;
    }

    /**     Method to set the output buffer to specifed array.
     *      Note the is no internal checking that it is a sensiblle length.
     *      @param out the output buffer
     */
    public void setOutputBuffer(double[] out) {
	outputBuffer = out;
    }

    /**     Method set the output buffer to new <code>double[]</code>
     *      array of specified length
     *      Note the is no sanity checkinng.
     *      @param size length of output buffer.
     */
    public void setOutputBuffer(int size) {
	outputBuffer = new double[size];
    }

    /**     Method to get the output buffer
     *      @return <code>double[]</code> the output buffer
     */
    public double[] getOutputBuffer() {
	return outputBuffer;
    }


    /**    Method to set the dimensions. Thsi class is not normally called
     *     by users unless they really know what they are doing!
     *     <p>
     *     Note this ONLY sets the dimensions, no other checking
     *     that they are consisted with the buffer sizes.
     *     @param iw the input width
     *     @param ow the output width
     *     @param h the height
     *     @param d the depth
     */
    public void setDimensions(int iw, int ow, int h, int d) {
	inputWidth = iw;
	outputWidth = ow;
	height = h;
	depth = d;
    }

    /**     Method to get the input array width.
     *      @return <code>int</code> the width of the input buffer
     */
    public int getInputWidth() {
	return inputWidth;
    }

    /**     Method to get the output data width. If the data is complex
     *      this will be the same as the input width.
     *      @return <code>int</code> the width of the output buffer 
     *      
     */
    public int getOutputWidth() {
	return outputWidth;
    }

    /**     Method to get the height, for a one-dimensional buffer this will
     *      be 1. Note the height of the input and output buffer will always
     *      be the same
     *       @return <code>int</code> the height of the input/output buffer 
     *      
     */
    public int getHeight() {
	return height;
    }


    /**      Method to get the depth, for a one or two-dimensional beffer
     *       this will be 1. 
     *       Note the depth of the input and output buffer will always
     *       be the same.
     *       @return <code>int</code> the depth of the input/output buffer 
     *      
     */ 
    public int getDepth() {
	return depth;
    }


    /**         Abstract  method to get the specifed input element
     *          as a Complex. 
     *          @param i the element index
     *          @return <code>Complex</code> specifed input element.
     */
    public abstract Complex getInputComplex(int i); 


    /**         Method to get the spefied input elements as complex
     *          using two dimensional access. Note, for efficiency there is
     *          no internal index checking.
     *          @param i the i index
     *          @param j the j index
     *          @return <code>Complex</code> specifed input element.
     */
    public Complex getInputComplex(int i, int j) {
	return getInputComplex(j*inputWidth + i);
    }

    /**         Method to get the spefied input elements as complex
     *          using three dimensional access. Note, for efficiency there is
     *          no internal index checking.
     *          @param i the i index
     *          @param j the j index
     *          @param k the k index
     *          @return <code>Complex</code> specifed input element. 
     */
    public Complex getInputComplex(int i, int j, int k) {
	return getInputComplex(inputWidth*(k*height + j) + i);
    } 
    /**         Absract method to get the specifed output element
     *          as a Complex.
     *          @param i the element index
     *          @return <code>Complex</code> specifed output element. 
     */
    public abstract Complex getOutputComplex(int i); 


    /**         Method to get the spefied output element as a complex
     *          using two dimensional access. 
     *          @param i the i index
     *          @param j the j index
     *          @return <code>Complex</code> specifed output element. 
     */
    public Complex getOutputComplex(int i, int j) {
	return getOutputComplex(j*inputWidth + i);
    }

    /**         Method to get the spefied output element as a complex
     *          using three dimensional access.
     *          @param i the i index
     *          @param j the j index
     *          @param k the k index
     *          @return <code>Complex</code> specifed output element. 
     */
    public Complex getOutputComplex(int i, int j, int k) {
	return getOutputComplex(inputWidth*(k*height + j) + i);
    } 



    /**       Method to get an input element is a double
     *        Only implemeneted for Real data
     */
    public abstract double getInputReal(int i);

    
    /**       Method to get an input element is a double using
     *        two-dimensional access
     *        @param i the in index
     *        @param j the j index
     *        @return <code>double</code> the element value
     */
    public double getInputReal(int i, int j) {
	return getInputReal(j*inputWidth + i);
    }

    /**       Method to get an input element is a double using
     *        three-dimensional access
     *        @param i the i index
     *        @param j the j index
     *        @param k the k index
     *        @return <code>double</code> the element value
     */

     public double getInputReal(int i, int j, int k) {
	return getInputReal(inputWidth*(k*height + j) + i);
    }



    /**     Abstarct to set an input element with a single real
     *      @param i the index
     *      @param a the real value
     */
    public abstract void setInputReal(int i, double a);

    /**      Method to set an inout element
     *       with a real using two-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param a the value
     */ 
    public void setInputReal(int i, int j, double a) {
	setInputReal(j*inputWidth + i,a);
    }
    
    /**      Method to set an input element
     *       with a real using three-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param k the k element index
     *       @param a the value
     */
    public void setInputReal(int i, int j, int k, double a) {
	setInputReal(k*inputWidth*(height + j) + i,a);
    }


    /**      Abstact method to set an input complex element
     *       with two doubles.
     *       @param i the element index
     *       @param a the real value
     *       @param b the imaginary value
     */ 
    public abstract void setInputComplex(int i, double a, double b);

    /**      Method to set an input input complex element
     *       with a complex
     *       @param i the element index
     *       @param c the Complex
     */ 
    public void setInputComplex(int i, Complex c) {
	setInputComplex(i,c.r,c.i);
    }
    
    /**      Method to set an input input complex element
     *       with a complex using two-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param c the Complex
     */ 
    public void setInputComplex(int i, int j, Complex c) {
	setInputComplex(j*inputWidth + i,c.r,c.i);
    }

    /**      Method to set an input input complex element
     *       with a complex ueing three-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param k the k element index
     *       @param c the Complex
     */
    public void setInputComplex(int i, int j, int k, Complex c) {
	setInputComplex(k*inputWidth*(height + j) + i,c.r,c.i);
    }

    /**      Abstact method to set an output complex element
     *       with two doubles.
     *       @param i the element index
     *       @param a the real value
     *       @param b the imaginary value
     */ 
    public abstract void setOutputComplex(int i, double a, double b);

    /**      Method to set an output complex element
     *       with a complex
     *       @param i the element index
     *       @param c the Complex
     */ 
    public void setOutputComplex(int i, Complex c) {
	setOutputComplex(i,c.r,c.i);
    }
    
    /**      Method to set an output complex element
     *       with a complex ueing two-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param c the Complex
     */ 
    public void setOutputComplex(int i, int j, Complex c) {
	setOutputComplex(j*inputWidth + i,c.r,c.i);
    }

    /**      Method to set an output complex element
     *       with a complex ueing three-diemnsional access
     *       @param i the i element index
     *       @param j the j element index
     *       @param k the k element index
     *       @param c the Complex
     */
    public void setOutputComplex(int i, int j, int k, Complex c) {
	setOutputComplex(k*inputWidth*(height + j) + i,c.r,c.i);
    }

    /**     Method to get basic information as a String.
     */
    public String toString() {
	String s = getClass().getName();
	s = s.substring(s.lastIndexOf('.') + 1);
	return s + ": iw: " + getInputWidth() + " ow: " +
	    getOutputWidth() + " h: " + getHeight() + 
	    " d: " + getDepth();
    }


    /**     Metho to make the current plan using the current defaults
     */
    public abstract void makePlan();


    /**      Method  perform the currebtly specifed fft. 
     *       The nethod will fail if there is no current active plan.
     */
    public void update() {

	if (plan >= 0) {               // Is there a valid plan
		nativeExecutePlan(plan);   // Excecute 
	}
	else {
	    errorStream.println("FFTWEngine.update: No valid plan.");
	}   
    }


    /**      Method  delete the current plan. Not that if the
     *       plan is delected a new plan MUST be made before 
     *       update can be called.
     */
    public void deletePlan() {
	if (plan >= 0 ) {             // Is there a valid plan
	    nativeDeletePlan(plan);   // Delete it
	    plan = -1;                // Remember it has been deleted
	}
    }
    
    /**     Native calls to ececute the specified  plan		
     */
    private native void nativeExecutePlan(int plan);

    /**     Native call to delete the current plan and clear the space
     */
    private native void nativeDeletePlan(int plan);
}
